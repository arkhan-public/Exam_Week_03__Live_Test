﻿// See https://aka.ms/new-console-template for more information

using System.ComponentModel;

List<Student> students = new List<Student>
{
    new Student { Id = 1, Name = "Alice Johnson", Age = 20, Department = "Computer Science", GPA = 3.8 },
    new Student { Id = 2, Name = "Bob Smith", Age = 22, Department = "Mathematics", GPA = 3.5 },
    new Student { Id = 3, Name = "Carol Davis", Age = 19, Department = "Computer Science", GPA = 3.9 },
    new Student { Id = 4, Name = "David Wilson", Age = 21, Department = "Physics", GPA = 3.2 },
    new Student { Id = 5, Name = "Emma Brown", Age = 20, Department = "Mathematics", GPA = 3.7 },
    new Student { Id = 6, Name = "Frank Miller", Age = 23, Department = "Physics", GPA = 2.9 },
    new Student { Id = 7, Name = "Grace Lee", Age = 19, Department = "Computer Science", GPA = 4.0 }
};

List<Course> courses = new List<Course>
{
    new Course { CourseId = 101, CourseName = "Data Structures", Department = "Computer Science", Credits = 3 },
    new Course { CourseId = 102, CourseName = "Calculus I", Department = "Mathematics", Credits = 4 },
    new Course { CourseId = 103, CourseName = "Physics I", Department = "Physics", Credits = 4 },
    new Course { CourseId = 104, CourseName = "Database Systems", Department = "Computer Science", Credits = 3 },
    new Course { CourseId = 105, CourseName = "Linear Algebra", Department = "Mathematics", Credits = 3 },
    new Course { CourseId = 106, CourseName = "Quantum Mechanics", Department = "Physics", Credits = 4 }
};

List<Enrollment> enrollments = new List<Enrollment>
{
    new Enrollment { StudentId = 1, CourseId = 101, Grade = "A" },
    new Enrollment { StudentId = 1, CourseId = 104, Grade = "B+" },
    new Enrollment { StudentId = 2, CourseId = 102, Grade = "B" },
    new Enrollment { StudentId = 2, CourseId = 105, Grade = "A-" },
    new Enrollment { StudentId = 3, CourseId = 101, Grade = "A" },
    new Enrollment { StudentId = 3, CourseId = 104, Grade = "A" },
    new Enrollment { StudentId = 4, CourseId = 103, Grade = "B" },
    new Enrollment { StudentId = 4, CourseId = 106, Grade = "C+" },
    new Enrollment { StudentId = 5, CourseId = 102, Grade = "A" },
    new Enrollment { StudentId = 5, CourseId = 105, Grade = "B+" },
    new Enrollment { StudentId = 6, CourseId = 103, Grade = "C" },
    new Enrollment { StudentId = 7, CourseId = 101, Grade = "A" }
};

/* ============================== LINQ Codes Starts ============================== */

// Question 1: Write a LINQ query to find all students who are older than 20 years. Display their names and ages.
// Answer 1:
var studentsOlderThan20 = students.Where(s => s.Age > 20)
                                    .Select(s => new { s.Name, s.Age });

Console.WriteLine("Answer # 1:");
Console.WriteLine("Students Older than 20:");
Console.WriteLine("=======================");
foreach (var student in studentsOlderThan20)
    Console.WriteLine($"Student Name: {student.Name}, Age: {student.Age}");
Console.WriteLine();

// Question 2: Write a LINQ query to get all courses sorted by credits in descending order. Display only the course name and credits.
// Answer 2:
var coursesSortedByCredits = courses.OrderByDescending(c => c.Credits)
                                    .Select(c => new { c.CourseName, c.Credits });

Console.WriteLine("Answer # 2:");
Console.WriteLine("Courses Sorted By Credits in Descending Order:");
Console.WriteLine("==============================================");
foreach (var course in coursesSortedByCredits)
    Console.WriteLine($"Course Name: {course.CourseName}, Course Credits: {course.Credits}");
Console.WriteLine();

// Question 3: Write a LINQ query to group students by their department and count how many students are in each department.
// Answer 3:
var studentsByDepartment = students.GroupBy(s => s.Department)
                                   .Select(g => new { Department = g.Key, StudentCount = g.Count() });

Console.WriteLine("Answer # 3:");
Console.WriteLine("Students Count Grouped By Departments:");
Console.WriteLine("======================================");
foreach (var student in studentsByDepartment)
    Console.WriteLine($"Department Name: {student.Department}, Students Count: {student.StudentCount}");
Console.WriteLine();

// Question 4: Write a LINQ query to join students and enrollments to find all students who have enrolled in "Data Structures" course. Display the student name and their grade.
// Answer 4:
var dataStructuresCourseId = courses.First(c => c.CourseName == "Data Structures").CourseId;

var studentsInDataStructures = enrollments.Where(e => e.CourseId == dataStructuresCourseId)
                                          .Join(students,
                                                e => e.StudentId,
                                                s => s.Id,
                                                (e, s) => new { StudentName = s.Name, Grade = e.Grade });

Console.WriteLine("Answer # 4:");
Console.WriteLine("Student Grades in Data Structure Course:");
Console.WriteLine("========================================");
foreach (var student in studentsInDataStructures)
    Console.WriteLine($"Student Name: {student.StudentName}, Student Grade: {student.Grade}");
Console.WriteLine();

// Question 5: Write a LINQ query to find the average GPA of all Computer Science students who have a GPA greater than 3.5.
// Answer 5:
var averageGpaOfHighAchievers = students.Where(s => s.Department == "Computer Science" && s.GPA > 3.5)
                                        .Average(s => s.GPA);

Console.WriteLine("Answer # 6:");
Console.WriteLine($"Average GPA of Computer Science Students having GPA > 3.5");
Console.WriteLine("==========================================================");
Console.WriteLine($"Average GPA: {averageGpaOfHighAchievers}");
Console.WriteLine();

/* ============================== LINQ Codes Ends ============================== */

public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Age { get; set; }
    public string Department { get; set; }
    public double GPA { get; set; }
}

public class Course
{
    public int CourseId { get; set; }
    public string CourseName { get; set; }
    public string Department { get; set; }
    public int Credits { get; set; }
}

public class Enrollment
{
    public int StudentId { get; set; }
    public int CourseId { get; set; }
    public string Grade { get; set; }
}
