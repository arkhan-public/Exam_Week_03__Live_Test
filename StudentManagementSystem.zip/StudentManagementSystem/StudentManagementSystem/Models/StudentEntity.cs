﻿using System.ComponentModel.DataAnnotations;

namespace StudentManagementSystem.Model
{
    public class StudentEntity
	{
        public int Id { get; set; }

        [Required]
        public required string FirstName { get; set; }

        [Required]
        public required string LastName { get; set; }

        [Required]
        [EmailAddress]
        public required string Email { get; set; }

        [Required]
        [Range(1, 150)]
        public int Age { get; set; }
    }
}
