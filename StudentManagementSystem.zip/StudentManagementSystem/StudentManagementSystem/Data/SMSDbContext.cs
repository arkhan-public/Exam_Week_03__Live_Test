﻿using Microsoft.EntityFrameworkCore;
using StudentManagementSystem.Model;

namespace StudentManagementSystem.Data
{
    public class SMSDbContext: DbContext
    {
        public SMSDbContext(DbContextOptions<SMSDbContext> options) : base(options)
        {
        }
        public DbSet<StudentEntity> Students { get; set; }
    }
}
